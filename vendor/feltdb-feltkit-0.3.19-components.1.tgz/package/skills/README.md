# FeltKit skills

Five Agent Skills (a folder each, with a `SKILL.md`) that teach a coding agent to build and operate FeltKit
applications. They ship inside `@feltdb/feltkit` at `skills/`, so the skills you install match the SDK you installed.

| Skill | For |
|---|---|
| `feltkit-build` | Project structure, the SDK, the React client, codegen, tests |
| `feltkit-services` | AppPort Services: enabling, using, configuring (secrets by reference), troubleshooting |
| `feltkit-data` | Collections, queries, writes, transactions, consistency guarantees |
| `feltkit-agent` | Operating a running app over MCP with FeltDB's agent state: tasks, handoffs, approvals, evidence |
| `feltkit-operations` | Doctor, inspect, build, test, deploy, sessions, state, recovery |

**They are guidance, not authority.** The application's roles decide what any caller may do; a skill cannot grant
a permission, approve an action, or reach a secret. They are not a runtime: the FeltKit agent (FeltDB agent state,
acting through AppPort) is the runtime they teach an agent to use.

## Install

In a FeltKit project (Claude Code; the only environment verified):

```sh
npx feltkit skills install           # copies them into .claude/skills/ (add --user for ~/.claude/skills/)
npx feltkit skills check             # validates what is installed against this SDK version
```

`install` again after upgrading `@feltdb/feltkit` to update; it replaces only skills it installed (`--force` to
replace others with the same name).

Or as a Claude Code plugin, from the installed package or this repository:

```sh
claude plugin marketplace add ./node_modules/@feltdb/feltkit/skills
claude plugin install feltkit@feltkit
```

## Compatibility

| Environment | Status |
|---|---|
| Claude Code (`.claude/skills/`, or the `feltkit` plugin) | Verified: installed and listed by Claude Code 2.1 in this repository's tests |
| Other agents that read `SKILL.md` folders | Not tested. They may work; verify before relying on them |

The skills describe `@feltdb/feltkit` at the version in `.claude-plugin/plugin.json`.
