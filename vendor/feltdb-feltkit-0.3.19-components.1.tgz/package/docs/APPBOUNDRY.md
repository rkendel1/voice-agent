# The AppBoundry target

`feltkit build --target appboundry` compiles an application into an artifact that
[AppBoundry](https://github.com/rkendel1/appboundry) runs on its own. FeltKit produces the
artifact; AppBoundry loads, authorizes and executes it; FeltDB and AppPort Services hold
its state, reached only through AppBoundry's host interfaces.

```bash
npx feltkit build --target appboundry   # [--out <dir>]
```

## Running an artifact

- **AppBoundry serves it**, `@appport/appboundry` **1.3.0 or later**:
  `npx @appport/appboundry@^1.3.0 run my-app.app --state <dir>`.
  - **Older releases can't, or not with the same guarantees.** 1.1.x has no `run`. 1.2.x runs
    the code but ignores `state.contract`, so FeltKit treats it as incompatible.
  - **Checking compatibility.** `appboundry --version --json` reports the format, ABI and host
    interfaces a runtime implements. FeltKit checks that report against the manifest
    (`src/appboundry/runtime.ts`), both in `feltkit build --target appboundry`, for a runtime
    installed in the project, and in the e2e test. An older runtime, or one that does not report
    `stateContract: "enforced"`, is refused by name.
  - **The e2e test.** `tests/e2e/appboundry-artifact.test.mjs` installs the published package
    from npm (before publication, `APPBOUNDRY_TARBALL=<packed tarball>`), never an AppBoundry
    checkout. It runs storage, authorization, the change stream, files, notifications,
    configuration, jobs, webhooks and a restart.
  - **The AppBoundry side.** AppBoundry's CI runs the same flow against its own packed tarball,
    using a FeltKit application from npm.
- **`createArtifactTestApp(path)`** (`@feltdb/feltkit/testing`) runs it in an in-memory reference
  host (`src/appboundry/host.ts`) with the same `as(who).query/mutation` calls as `createTestApp`,
  so a project can run its own tests against the compiled module. It loads only `manifest.json`
  and `module.wasm` (checking the module's SHA-256), speaks the guest ABI, checks access before
  arguments, keeps records in memory with atomic per-call commits validated by the manifest's
  schemas, and provides files, notifications and configuration (seed it with
  `{ configuration: {...} }`); jobs and webhook events are recorded (`t.host.jobs`,
  `t.host.webhookEvents`), not run. It is for verification, not serving.

## Deploying through AppBoundry: `feltkit deploy --target appboundry`

FeltKit builds the application and its immutable artifact. AppBoundry registers, deploys, executes and
operates it. The developer never generates or manages the execution environment: whether an AppBoundry
host runs artifacts in Docker, Podman, a microVM or something else is AppBoundry's choice, and FeltKit
does not depend on it.

```bash
npx feltkit deploy --target appboundry      # APPBOUNDRY_URL, APPBOUNDRY_TOKEN (a deploy token); APPBOUNDRY_HOST optional
npx feltkit status
```

| Output | Owner | What it is |
|---|---|---|
| Application artifact | FeltKit build | `.feltkit/appboundry/<name>.app`: manifest, module that imports nothing, frontend |
| Deployment request | FeltKit → AppBoundry | the artifact uploaded as a deterministic `.tar.gz` (with `x-archive-sha256`), then a deployment intent (`artifactId`, optional host, `Idempotency-Key`) |
| Execution environment | AppBoundry | never visible to FeltKit |

`src/cli/deploy-appboundry.ts` speaks AppBoundry's managed-hosting API with a **deploy token** the platform
owner issues (scoped to one application or an organization; revocable; optional expiry):
`GET /api/applications/{id}/hosting`, `POST …/artifacts`, `POST …/deployments`, `GET …/deployments/{id}`.
AppBoundry verifies the upload itself, stores it immutably, and registers the application from the verified
manifest the first time (when the token's scope allows). Without `APPBOUNDRY_HOST`, AppBoundry places the
deployment. FeltKit checks that the artifact AppBoundry accepted is this build (`artifactId` = SHA-256 of
`manifest.json`, and the module digest) and reports **Running** only when AppBoundry says Running and its
evidence (from the runtime, via the host's agent) names this build's module, on the current attempt.
`feltkit status` asks AppBoundry, using the references in `.feltkit/appboundry/deployment.json` (never the
token). The contract: [APPBOUNDRY-DEPLOY-CONTRACT.md](APPBOUNDRY-DEPLOY-CONTRACT.md).

**What is not there yet, on AppBoundry's side:** public routing (a Running deployment has no address yet:
FeltKit says so), and execution of deploy-token deployments in production: AppBoundry keeps its isolation
release gate closed until the runtime's isolation requirements pass, and answers `NO_EXECUTION_CAPACITY
(untrusted_execution_disabled)` meanwhile. The artifact is stored; nothing runs.

### Running the AppBoundry runtime yourself: `--target appboundry-self-hosted`

A separate product with its own contract: `.feltkit/deploy` with the artifact, a Dockerfile that installs
the published `@appport/appboundry` (pinned, `APPBOUNDRY_DEPLOY_VERSION`), AppBoundry's artifact-runner
entrypoint (refuses any other module, verifies, bootstraps the operator), `docker-compose.yml`,
`deploy.json` and `DEPLOY.md`. Use it when you operate the execution environment; it is not how AppBoundry
deploys. Access: `appboundry admin users add` and `appboundry admin sessions issue` through
`docker compose exec`; the starter's sign-in screen accepts the issued session.

## What is in `my-app.app`

| File | Contents |
|---|---|
| `manifest.json` | format `appboundry.app/1`; guest ABI and host-interface versions; the application; every function (kind, access, argument and result JSON Schemas, the capability it publishes); every collection and its schema; roles, dev users and session lifetime; the services the code uses; the host permissions (collections, services, `network: "none"`, `filesystem: "none"`); the AppPort manifest; SHA-256 of the module, the program and every frontend file; and, in words, what the artifact leaves out |
| `module.wasm` | the guest engine (`appboundry/engine.wasm`, a JavaScript engine built from `appboundry/engine`) with the program in its `appboundry.program` section. It imports nothing |
| `assets/` | `dist/client`, the built frontend |

Every description comes from the loaded application: functions, collections and roles from
its definitions, and the AppPort contract from the same capability definitions the FeltKit
runtime serves (`src/runtime/capabilities.ts`). Nothing is described twice.

The program is your `feltkit/` modules bundled with FeltKit's guest runtime
(`src/appboundry/guest.ts`). The build loads the finished module the way AppBoundry will and
checks that it defines exactly the functions the build does.

## What stays the same

Handlers run with the same `ctx`:

- **`ctx.db`**: reads and writes are AppBoundry operations. A mutation's writes are buffered
  and commit atomically when it returns (nothing if it throws), with FeltKit's version
  preconditions and read fences; reads see the mutation's own pending writes; a query cannot
  write. Records are validated by the guest with your schemas, and again by AppBoundry with the
  manifest's.
  `ctx.db.search` runs in the guest on the existing read operations (`db.query` pages in a
  query, `db.find` in a mutation, its `where` pushed down), so it needs no new host interface.
- **`ctx.auth`**: the principal and its permissions, from your roles. `access` is enforced by
  AppBoundry before the handler runs.
- **`ctx.services`**: files, notifications, configuration, jobs (`enqueue`, run as the
  enqueuer) and webhooks (`emit`), run by AppPort Services as the caller.
- Errors: `fail()` and `FeltKitError` reach the caller with the same codes and messages.
- The frontend: `@feltdb/feltkit/client` and `/react` work unchanged, live queries included.
- AppPort: the published capabilities are served at `/appport`.

## Signing in, and where the data is

An artifact has no development sign-in in production and no FeltKit CLI beside it, so
`npx feltkit session create` does not apply to it. AppBoundry's operators create users with
the roles your app declares and issue their sessions (`appboundry admin users add`,
`appboundry admin sessions issue`); a production user is never asked to run a FeltKit
command. AppBoundry also decides where the data is: a local state directory, or a Managed
FeltDB environment from its own runtime configuration. The artifact, and your code, are the
same either way; FeltKit does not know which one runs it, and nothing is rebuilt to switch.

Built-in accounts (`auth.accounts`) and tenancy (`auth.tenant`) are FeltKit server routes
(`/api/auth/*`, `/api/tenants/*`) that an AppBoundry host does not serve (FK-GAP-013). The build
warns, and declares them in the manifest (`identity.accounts`, `identity.tenancy`) so the host can
refuse the artifact unless its operator accepts that people get sessions only from an operator,
and that tenant-scoped collections stay closed. See [AUTH.md](AUTH.md#appboundry).

## Schema lifecycle in an artifact

`manifest.json` carries `state.contract`: the FeltDB state contract the application's
collections compile to (`s.ref` references, unique constraints, indexes), at version 1.

**What a host does with it:**

- **First load.** The host installs the contract on FeltDB.
- **A later artifact version.** The host installs the new contract only when every stored
  record satisfies it. Otherwise it refuses to load the new version and changes nothing, and
  the previous version keeps running on the same data.
- **A populated collection the new version drops** is refused too, as on a FeltKit server.

**Migrations.** The application's `app.migration()`s are bundled into `module.wasm` with every
other function; no code travels as data, and there is no second migration format. The manifest
lists them by name, in declaration order:

```json
"runtime": { "interfaces": { "...": 1, "migrations": 1 } },
"state": { "contract": { "...": "..." }, "migrations": { "format": "appboundry.migrations/1", "order": ["tasks get a priority"] } }
```

Before serving a new artifact version, a host:

1. runs each pending migration (one not yet recorded in the store's history) once, in order, in
   the guest (invocation `{ migration: name }`). It runs through FeltKit's own migration context
   (`src/runtime/migration-context.ts`, the one FeltKit's runtime uses): reads are the host
   operation `migration.records` (application collections only), and writes are staged;
2. commits the staged writes, the new contract and a history record in one FeltDB evolution,
   in which FeltDB re-validates every record. Writes to a collection the new contract drops
   go through an intermediate contract version, as on a FeltKit server;
3. records what it actually applied: the migrations, records put and deleted, the contract
   versions, and who authorized the start.

A migration that throws, or leaves a record the new contract refuses, refuses the new version and
changes nothing. The previous version keeps running on the same data. An applied migration never
runs again. Only `appboundry.migrations/1` is accepted; any other format is refused when the
artifact loads. An artifact without migrations doesn't require the `migrations@1` interface.

**The reference host does this:** `createArtifactTestApp(path, { stateDir })` runs successive
artifact versions on one FeltDB state directory. `test/schema-lifecycle-artifact.test.ts`
covers an unchanged schema, an optional field, a refused required field, a dropped
collection, and references and unique constraints answering as on a FeltKit server.

**AppBoundry (1.3.0 and later) does the same; 1.4.0 and later also runs the migrations.**
Before serving, it:

1. validates the contract with FeltDB's validator;
2. refuses one that redefines a platform (Services-owned) collection or doesn't match the
   manifest's collections;
3. composes it with the AppPort Services collections the artifact uses;
4. runs the pending migrations (1.4.0), then installs or evolves the contract with
   `db.stateContract.evolve`, the migrations' writes included.

A change the stored records don't satisfy (after the migrations), a failing migration, or one
that drops a populated collection, refuses to start with `SCHEMA_INCOMPATIBLE`. The error's
details list the changes, the migration and its error code or the failing record, and the
previous version and data stay usable. History is in `_appboundry_contract`.
`appboundry run --no-migrate` refuses any schema change or pending migration instead, for
deployments that authorize those separately. Authorizing a change and applying it are different
records: the host records what it applied, whoever allowed the start.

Contract refusals answer with FeltKit's codes:

| Refusal | Code |
|---|---|
| Duplicate unique value | `CONFLICT` |
| Missing or still-referenced record | `FAILED_PRECONDITION` |
| Other contract rules | `VALIDATION_FAILED` |
| Undeclared collection | `NOT_FOUND` |

`tests/e2e/state-contract-parity.test.mjs` requires FeltKit's runtime, the AppBoundry source
build and the AppBoundry package to give the same outcome and code for every step:

- a valid write;
- a missing required field;
- a duplicate unique value;
- a missing reference;
- deleting a referenced record;
- an undeclared collection;
- a restart;
- a compatible upgrade;
- an incompatible upgrade;
- the previous version again;
- a required field with a backfill migration;
- a field removed with a transformation migration;
- a failing migration (refused);
- the previous version again, unchanged, with no migration run twice.

The records each runtime leaves must be the same, too.

An artifact with migrations needs AppBoundry 1.4.0 or later: `feltkit build --target appboundry`
names an installed 1.3 runtime as not implementing `migrations@1`.

## What the build refuses

Each of these makes the build fail, naming where it is used, rather than producing an
artifact that behaves differently from your application:

| Use | Why |
|---|---|
| `ctx.unsafe.feltdb` | it writes FeltDB around validation and transactions; an artifact reaches state only through `ctx.db` |
| `ctx.agent` | FeltKit's agent runs in the FeltKit server |
| `app.agent` (and `ctx.afterCommit.agent`) | application agents run after a commit, as their own principal, on FeltKit's runtime; the host protocol runs guest code only inside a call, as its caller (docs/TRANSACTIONS.md §8) |
| `app.integration(...)` | integrations call external APIs; an artifact has no network access |
| `feltkit({ auth: { authenticate } })` | not yet supported; identity comes from AppBoundry sessions |
| `Intl`, `toLocaleString` / `toLocaleDateString` / `toLocaleTimeString`, `localeCompare` | the guest engine has no locale data (see below), so they would give different output than under `feltkit dev` |
| Node APIs (`node:*`, `fs`, …) in backend code | the artifact runs without Node |
| imports of `@feltdb/feltkit/<subpath>` in backend code | only `@feltdb/feltkit` exists in the guest |

Only the handler context is checked: `ctx.agent` (or the first parameter of a `handler`,
whatever it is named, and `({ agent })` destructured) is refused, while `roles.agent` or
`req.agent` is not. `ctx.unsafe`, `ctx.agent` and the locale methods also throw at run time if
reached some other way.

## Sequences and after-commit effects (transactions@1)

An application that uses `ctx.db.sequence` or `ctx.afterCommit` (or opts a mutation into
`retry`) builds to an artifact that requires the host interface `transactions@1`; a host without it
refuses the artifact when it loads, and `feltkit build` names the AppBoundry release that has it
(1.5.0). The guest asks the host for `db.sequence { name }` (the host draws it in the mutation's
transaction) and, when the handler returns, `outbox.stage { effects }` (FeltKit's own
`afterCommit`, validated again by the host, with the caller and request taken from the call). The
host commits both with the mutation's writes, performs the effects after the commit as the caller,
recovers them after a restart, and lets an operator list and retry failed ones
(`appboundry admin outbox list | retry <id>`). A manifest function's `retry: { sequenceConflicts }`
is honored the same way as on a FeltKit server. The contract: [TRANSACTIONS.md](TRANSACTIONS.md). A plain `feltkit build`
prints the same list as a warning ("Not portable to --target appboundry").

## The guest's ECMAScript surface

The guest engine is Boa (`boa_engine` 0.22, `appboundry/engine/Cargo.toml`) built without
its `intl` feature, to keep `engine.wasm` small and free of ICU data. ES2022 code runs as
compiled by esbuild (`target: es2022`). What differs from Node:

| Feature | In the artifact |
|---|---|
| `Intl.*` | refuses with `CONFIGURATION` ("Intl is not available in an AppBoundry artifact") |
| `Number/BigInt/Array.prototype.toLocaleString`, `Date.prototype.toLocaleString/DateString/TimeString` | refuse the same way, instead of formatting differently (`(12400).toLocaleString("en-US", …)` would be `"12400"`, not `"12,400.00"`) |
| `String.prototype.localeCompare` | refuses; compare with `<` and `>` (code-unit order) |
| Time zones | the host gives the clock (`abg_clock`, UTC milliseconds); there is no time-zone database, so format dates in the frontend or with explicit UTC arithmetic |
| `TextEncoder` / `TextDecoder` | UTF-8, installed by the guest |
| Node globals (`Buffer`, `process`, `require`) | absent; Node imports fail the build |

Format numbers and dates for people in the frontend, or with explicit code (`toFixed`,
your own digit grouping).

## What is not in the artifact

The build lists these (`omitted` in the manifest) instead of pretending to carry them:
Studio and the MCP endpoint, API keys, schedules, intelligence, and webhook delivery
(`emit()` records the event; AppBoundry delivers nothing because the artifact has no network),
and the account and tenant routes of `auth.accounts` and `auth.tenant` (also declared in `identity`).

## Rebuilding the engine

`appboundry/engine.wasm` is prebuilt so applications never need Rust. To rebuild it (Rust with
the `wasm32-unknown-unknown` target):

```bash
node packages/sdk/scripts/build-appboundry-engine.mjs
```
