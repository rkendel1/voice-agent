# FeltKit → AppBoundry deployment contract

**Status: implemented on both sides and tested end to end locally (FeltKit CLI → AppBoundry portal → execution agent → runtime);
not deployed.** The contract is owned by AppBoundry: `rkendel1/appboundry` `docs/contracts/feltkit-deploy/CONTRACT.md`.
Both repositories test against the same fixtures: here `packages/sdk/test/fixtures/appboundry-contract.json`, there
`docs/contracts/feltkit-deploy/fixtures.json` (byte-identical; change both together).

The principle: FeltKit builds the application and its immutable artifact. AppBoundry receives, registers, governs, deploys,
executes and operates it. FeltKit never generates, sees or depends on the execution environment (no hosts, containers, Docker,
systemd or Hetzner here).

```
npx feltkit deploy --target appboundry     # build → upload → register if needed → deploy → wait for evidence
npx feltkit status                          # what AppBoundry says now
```

## FeltKit's side

| | |
|---|---|
| Configuration | `APPBOUNDRY_URL` (https; http only to loopback), `APPBOUNDRY_TOKEN` (a deploy token, environment only), optional `APPBOUNDRY_HOST` |
| Credential | `Authorization: Bearer abd_…`. Never printed, logged, written to `.feltkit/`, or put in the artifact |
| Artifact | `feltkit build --target appboundry` output, sent as a deterministic ustar `.tar.gz` (sorted, mode 0644, uid/gid 0, mtime 0) with `x-archive-sha256` |
| Identity check | Before deploying: the `artifactId` AppBoundry returns must equal `sha256(manifest.json)` of this build, and its module digest this build's module. Otherwise nothing is deployed |
| Deployment | One `Idempotency-Key` per run; no host unless `APPBOUNDRY_HOST` is set (AppBoundry places it) |
| Running | Only when `state === "Running"` and the evidence names this build's module, on the deployment's current attempt, with the observed instance and runtime. `Running` with other evidence is reported as a failure, never as running |
| Pending | Still `Requested`/`Starting` after the wait (5 min): reported as pending; `feltkit status` asks again |
| Local record | `.feltkit/appboundry/deployment.json`: portal, ids, digests, `lastStatus`, `lastObservedAt`. A note, not the truth: `feltkit status` always asks AppBoundry |
| Address | Shown only when AppBoundry reports one (`address`, `routing`); state and routing are separate |

## Errors as the developer sees them

| AppBoundry | FeltKit |
|---|---|
| `401 AUTHENTICATION_REQUIRED` | `UNAUTHORIZED`: the token is missing, malformed, unknown, revoked or expired |
| `403 FORBIDDEN` | `FORBIDDEN`: the token's scope does not include this application |
| `404 APPLICATION_NOT_REGISTERED` | `NOT_FOUND`: this token may not register the application |
| `503 NO_EXECUTION_CAPACITY` (+ `details.reason`) | `UNAVAILABLE` with the reason; the artifact is stored, nothing was deployed |
| `400 ARCHIVE_DIGEST_MISMATCH` | `UNAVAILABLE` (retryable): the upload was damaged, nothing was stored |
| portal unreachable | `UNAVAILABLE`, never a deployment state |
| artifact identity differs | `FAILED_PRECONDITION`: nothing was deployed |

## Tests

- `packages/sdk/test/appboundry-contract.test.ts`: the shared fixtures (the archive vector byte for byte, what counts as Running,
  error mapping, the local record).
- `packages/sdk/test/deploy-appboundry.test.ts`: the client against an in-process stand-in of the portal.
- End to end, in AppBoundry: `packages/appboundry-agent/test/feltkit-deploy-e2e.test.ts` runs this CLI against the real portal,
  agent, Docker driver and runtime (`FELTKIT_REPO` points at this checkout).
