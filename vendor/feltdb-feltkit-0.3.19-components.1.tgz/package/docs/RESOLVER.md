# Model references with Resolver

Change the model a deployed FeltKit app uses without changing, rebuilding or redeploying the
app. The app names a stable reference, `ref://prod/chat/model`. [Resolver](https://www.npmjs.com/package/@appport/resolver)
decides what it points to, now and after every change.

```ts
// feltkit/app.ts
export const app = feltkit({
  name: "acme",
  agent: { model: { production: "ref://prod/chat/model", development: "ref://dev/chat/model" } },
  // …
});
```

```bash
# An operator, in Resolver (the app is not touched):
resolver set ref://prod/chat/model --value '{"provider":"anthropic","model":"claude-sonnet-5-5","credential":"ref://prod/llm/anthropic-key"}' --reason "cost review"
```

The agent's next decision runs on the new target, and its record says which revision it used.

## What is in this release

The agent's model decisions (`ctx.agent.start`, `playbook: "decide"`) are the one reference type
supported. Other kinds (endpoints, credentials for integrations, agents, configuration values)
are listed under [Not yet](#not-yet).

## Who owns what

| | Owns | Here |
|---|---|---|
| **Resolver** | references, bindings, revisions, history, rollback, grants, secret material (its vault), change notifications | the source of truth for what `ref://…` means; FeltKit never stores a copy of a binding |
| **FeltKit** | which reference an environment uses (`agent.model`), calling the model, recording what each decision used | `ModelHost` resolves through `@appport/resolver-client`, executes with its OpenAI-chat or Anthropic runtime, records the receipt |
| **FeltDB** | the app's durable state | the decision record (agent memory) holds the receipt next to the choice |
| **AppPort** | capabilities and authority | Resolver is an AppPort service; the client calls `resolver.resolve` with this deployment's key, checked by Resolver's own grants |
| **AppPort Services** | the Intelligence catalog | Resolver checks a model's provider against it when a binding is written; FeltKit picks the protocol and default endpoint from it |

There is no second store, permission system or secret vault. Resolver authorizes every
resolution with its own grants; FeltKit's roles still decide who may start agent work.

## Setting it up

1. **Run Resolver** (`npm install -g @appport/resolver`; `resolver init`, then `resolver serve`).
   See its README for state, vault and multi-instance options.
2. **Bind the reference** (as an operator, with an admin key):
   ```bash
   resolver set ref://prod/llm/anthropic-key --kind secret --secret-stdin   # the key, on stdin
   resolver set ref://prod/chat/model --kind model --value '{"provider":"anthropic","model":"claude-sonnet-5-5","credential":"ref://prod/llm/anthropic-key"}'
   ```
   The provider must be in the AppPort Services Intelligence catalog (`openai`, `anthropic`,
   `opencode`, `ollama`, `custom`). Resolver refuses a binding that names an unknown provider or
   model, a missing credential, or a credential placed in `options`.
3. **Give the deployment its own key**, allowed to read the reference and reveal its credential, and
   nothing else:
   ```bash
   resolver keys create acme-production --grant read:ref://prod/chat/model --grant read,reveal:ref://prod/llm/*
   ```
4. **Configure the app**: `agent.model` in `feltkit({ … })`, and in the deployment's environment
   `RESOLVER_URL` (the origin) and `RESOLVER_API_KEY` (the key from step 3). `feltkit deploy` lists
   both in the artifact's `.env.example` and contract when the app names a reference. The values
   are never in the artifact.

## Seeing what is in use

- `feltkit model show --env production`: the provider and model the reference resolves to now, the
  reference, its revision and credential reference, and what to fix if it does not resolve.
- Studio → Models: the same, with the source shown as Resolver.
- Each agent decision's checkpoint reads `anthropic/claude-sonnet-5-5 (ref://prod/chat/model r7) chose …`,
  in Studio and over MCP (`feltkit_agent_get`). The decision's memory record, cited as evidence,
  holds the full receipt: `ref`, `revision`, `label` (for weighted bindings), `provider`, `model`,
  `endpoint`, `credential` (the reference, never the key), `credentialRevision`, `resolvedAt`.
- History, diffs and rollback are Resolver's: `resolver history ref://prod/chat/model`.

`feltkit model set` and Studio's model picker refuse to change an environment that a reference
governs (the choice would be stored and never used), and name the `resolver set` command instead.

## When a change takes effect

FeltKit connects to Resolver on first use and subscribes to the reference. What the guarantee is:

- **Through the change stream.** Resolver notifies connected clients of a change (name and revision
  only). The cached result is dropped, and the next decision resolves again. Measured in the tests:
  within seconds, with a 300 s TTL, across separate processes.
- **At the latest, the reference's TTL** (`--ttl`, default 30 s). A missed notification (a reconnect,
  another Resolver instance, which polls every second) is bounded by it.
- **Per decision, one resolution.** A decision's target, credential and receipt come from one answer,
  so a change landing during a call cannot mix two revisions. The call in progress finishes on the
  revision it started with; the receipt says which.
- **Resolver unreachable:** a result resolved earlier is served for up to 5 minutes, then decisions
  fail. A not-found, revoked or forbidden answer is never covered over: it evicts the cache.

A decision that is already running is not interrupted by a change.

## Failure behavior

Nothing falls back to another model or to the Intelligence selection. Each failure blocks the
agent task with what to fix (`problem` in the error's details):

| Problem | When |
|---|---|
| `not_configured` | `RESOLVER_URL` or `RESOLVER_API_KEY` is not set |
| `reference_missing` | the reference does not exist or was revoked |
| `reference_forbidden` | this deployment's key has no `read` grant on it (or `reveal` on its credential) |
| `reference_invalid` | not a model reference, a provider outside the catalog, or no endpoint |
| `credential_missing` | the provider needs a key and the binding names no credential |
| `resolver_unavailable` | Resolver cannot be reached and no cached result is left |

## Secrets

The provider key is a `secret` reference held in Resolver's vault. FeltKit's process receives the
material for one call, in memory (Resolver's client keeps it for at most the reference's TTL), and
passes it to the provider's API. It is not written to FeltDB, decision records, activity, logs,
status views, errors, prompts or the deploy artifact. The receipt names the credential's reference
and revision, never its value. The acceptance test checks every one of those places for the key.

An app with `reveal` holds the material in memory while it uses it (Resolver's README, Limits).
Keep the grant narrow: `reveal` on the provider keys the app uses, not `*`.

## Environments

`agent.model` maps environment names to references. An environment it does not name keeps the
Intelligence selection, so a test environment cannot reach a production reference by accident.
Use one Resolver key per deployment, granted only its environment's references
(`ref://prod/*` for production). Resolver tenants and grants keep environments apart. FeltKit
never rewrites a reference name.

## Proven by

- `packages/sdk/test/resolver-model.test.ts`, run against the real Resolver in-process:
  - provider A, then provider B with a credential, with no restart;
  - the change arrives through the change stream, not by TTL expiry;
  - receipts, and the durable decision record;
  - each failure above;
  - per-environment references;
  - the refused `feltkit model set`.
- `tests/e2e/resolver-switch.test.mjs`:
  - a starter app deployed once (`--target container`);
  - Resolver as its own process (its CLI);
  - A → B with no rebuild, redeploy or restart;
  - the first decision still names A at r1;
  - a restart keeps resolving;
  - the key is in no decision, process output, artifact or state file.

  The two providers are loopback OpenAI-compatible servers (`ollama`, `custom`); everything else
  is the real software.

## Not yet

- **Other reference kinds.** Integration endpoints (`endpoint` refs for `app.integration`),
  integration credentials (`secret` refs in place of `FELTKIT_CREDENTIAL_<ID>`), AppPort agents
  (`agent` refs) and configuration values (`value` refs) all need the same treatment:
  - a typed declaration;
  - resolution inside the existing call path;
  - a receipt.
- **Weighted bindings with a stable key.** Steering works (the receipt has `label`), but FeltKit
  passes no `key`, so a canary split is per call, not sticky per user or tenant.
- **Pinning a revision** (`resolve(ref, { revision })`) from the app is not exposed.
- **Credential custody outside the app process.** The key enters FeltKit's process for the call.
  A provider proxy that holds the key would avoid that; none exists yet.
- **Managing references from Studio.** Studio shows the reference and its revision. Changes are made
  in Resolver (its CLI or management pages), which owns their authorization and history.
- **Resolver's own pins.** `@appport/resolver` 0.2.0 pins `@feltdb/core` 0.21.0 and
  `@appport/services` 0.15.0, the same versions FeltKit uses. It is a separate service, so the
  versions never mix in the app; the app depends only on `@appport/resolver-client`. The tests install it the
  same way, outside the workspace (`test/fixtures/resolver-service.mjs`), so FeltKit keeps exactly
  one `@feltdb/core` (the release check).
