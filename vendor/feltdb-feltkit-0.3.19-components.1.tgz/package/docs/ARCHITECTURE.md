# Architecture

```
Developer ─► feltkit (definitions, CLI) ─► FeltKitRuntime ─┬─► AppPort (capability boundary)
                                                                ├─► AppPort Services (Files)
                                                                └─► FeltDB instance for this environment
```

Every arrow that reaches state ends at the same FeltDB instance. Operations take the
shortest correct path:

| Operation | Path |
|---|---|
| App query/mutation over HTTP | server → `runtime.call` → authority → `ctx.db` → FeltDB |
| Capability via AppPort or MCP | AppPort `HttpBinding`/MCP bridge → AppPort dispatch (validate → authorize → execute) → `runtime.call` → FeltDB |
| Service effect | `ctx.services.files` → AppPort Services `ServiceGateway` (authorize → effect → evidence) → FeltDB |
| Live query update | FeltDB operation journal (+ the commit's described writes) → change feed → SSE, filtered per subscriber (tenant) with opaque predicate keys → client re-runs the queries whose predicates the change meets |
| Dashboard | admin API (admin token) → the same runtime and instance |

## Components

| Module | Responsibility |
|---|---|
| `runtime/instance.ts` | `InstanceFactory`: the only `createFeltDB` call. One instance per environment; refuses duplicates and aliased environments in the process, and maps FeltDB's owner lock (`STATE_LOCKED`, another process) to `DUPLICATE_INSTANCE`. Hands out component handles. |
| `runtime/environment.ts` | Resolves an environment to its storage (local path, FeltDB server, memory). |
| `runtime/data.ts` | `ctx.db`. Read-only `Reader` for queries; `Writer` buffers writes and commits one FeltDB transaction with version preconditions. |
| `runtime/authority.ts` | Roles → permissions evaluated by AppPort's `permissionAuthorizer`; adapters for the function boundary and AppPort Services' `ServiceAuthorizer`. |
| `runtime/sessions.ts` | AppPort `SessionStore` implemented on FeltDB; token digests only. |
| `runtime/services.ts` | AppPort Services via `createServices({ db })` on the shared instance, checked with `services.usesInstance`; bindings for `ctx.services`; service states from `services.health()`; evidence lookups (`services.evidence.findByRunId`); configuration export/import; the durable-work tick. |
| `runtime/credentials.ts` | Credential custody, AppPort Services' `SecretCustody` (withSecret, store, status, remove): `credential-ref:<id>` → `FELTKIT_CREDENTIAL_<ID>` when set, else the environment's encrypted vault (`.feltkit/<env>/credentials.vault`; production only with `FELTKIT_CREDENTIAL_VAULT=1` + `FELTKIT_CREDENTIAL_VAULT_KEY`). One instance per runtime, given to `createServices({ credentials })`; values are resolved inside the effect only and written only through `credential.store`. |
| `runtime/agent.ts` | The FeltKit agent: FeltDB `defineAgent`/executions (`findAgentExecution`, `resumeAgentExecution`, `cancelAgentExecution`) + `openAgentState` (`listTasks`, `listHandoffs`) on the shared instance; actions only through AppPort and AppPort Services; the action lifecycle (compare-and-swap state changes on FeltDB agent memory, restart reconciliation from evidence); approvals; playbooks; handoffs. |
| `runtime/idempotency.ts` | AppPort's published `IdempotencyStore` on FeltDB: atomic in-progress claims (a FeltDB `requireAbsent` / `ifVersion` transaction), records, release, and lookup by request id, so a replay after a crash is "outcome unknown" and records survive a restart. Checked by `@appport/testing`'s conformance suite. |
| `runtime/activity.ts` | Durable activity log built from commit results; links to Services evidence. |
| `runtime/changes.ts` | Change feed from FeltDB's operation journal (kept over collection subscriptions: see docs/UPSTREAM-GAPS.md F1/F7), with the keyed values of writes FeltKit committed. |
| `runtime/live.ts` | Live queries by predicate: keyed fields, the read set with its equality predicates, opaque keys (process-key HMAC). |
| `runtime/search.ts` | `ctx.db.search`: normalization, matching, the bounded scan (shared by the runtime and the AppBoundry guest). |
| `runtime/content.ts` | File bytes in `_feltkit_file_content`: stored before the file record, verified on read, removed with the file (FeltDB's content store is not used yet: no deletion, no memory runtime). |
| `runtime/runtime.ts` | Lifecycle, hot reload, `call()`, AppPort application construction. |
| `runtime/loader.ts` | Loads `feltkit/` (tsx in development, the esbuild bundle in production). |
| `server/` | HTTP server, AppPort binding, MCP endpoint (application tools + `feltkit_agent_*`), admin API, dev/build/start/deploy workflows. |
| `server/management.ts` | AppPort Services' `createManagementRouter`: embedded in the admin API for Studio's Services screens (as a dev identity), and the services console on a loopback origin, authenticated by FeltKit sessions. |
| `client/`, `react/` | Browser client, typed references, live queries, hooks. |
| `cli/` | The `feltkit` command, including `feltkit skills`. |
| `skills/` | The FeltKit Agent Skills and their Claude Code plugin manifest (shipped in the tarball). |
| `dashboard/` | The dashboard SPA (built into `dist/dashboard`). |

## Component handles

`instance.handle("appport-services")` returns a `Proxy` over the environment's
`StateFirstDB`. Calls forward to the same object unchanged; the proxy records which
collections each component reached and refuses `close()` (the runtime owns the
lifecycle). Tests use `instance.owns(x)` to prove a component's database *is* this
instance, not one with matching configuration.

Components and the handles they receive:

| Component | Handle |
|---|---|
| Application functions | `app` (and `app.unsafe` for the escape hatch) |
| AppPort application (`createApplication({ db })`) | `appport` |
| AppPort Services stores, gateway evidence | `appport-services` |
| File bytes | `feltkit.files` |
| Sessions | `feltkit.sessions` |
| Activity log | `feltkit.activity` |
| Change feed | `feltkit.changes` |
| Dashboard / admin API | `feltkit.admin` |
| FeltKit agent (FeltDB agent definition, executions, agent state) | `feltdb.agent` |
| AppPort idempotency records | `appport.idempotency` |
| Services console | none of its own: it mounts the services above, which hold `appport-services` |

## How AppPort Services is constructed

`runtime/services.ts` calls the package's own `createServices({ db })` with the shared
instance's `appport-services` handle and FeltKit's `ServiceAuthorizer`, then refuses to
start unless `services.usesInstance(handle)` is true and `services.ownsDb` is false (the
services run on the host's instance and never opened their own). Everything else FeltKit
needs from the package is public API (`@appport/services` 0.9.1; these APIs arrived in 0.6.0, the credential write path in 0.8.0, the contract fragment in 0.9.0 and its indexes in 0.9.1):

- service state: `services.health({ tenantId })` (counts and reasons only; a trusted
  in-process read that authorizes nothing and writes nothing);
- effect evidence for a request: `services.evidence.findByRunId(requestId)`, where the
  request id is the `runId` FeltKit gives every service effect inside it; `started` with no
  completion means the outcome is unknown;
- the agent's delivery diagnosis: `invoke('webhooks.deliveries.read')` as the task owner;
- `feltkit config export|import`: `services.configuration.export/import`;
- storing a credential value: `invoke('credential.store')` as the caller, with FeltKit's
  `SecretCustody` given to `createServices({ credentials })` (runtime/credentials.ts);
- the version: `VERSION`.

One private read remains: `credentialReferences()` reads `ConfigurationSecrets` (names and
references) to report whether each reference resolves in FeltKit's custody, because the
public reads are authorized effects that write evidence (docs/UPSTREAM-GAPS.md, S3b).
`test/services.test.ts` and `test/services-released.test.ts` verify each service and each
of these APIs against the real package on the shared instance.

## One copy of FeltDB

FeltKit depends on `@feltdb/core` `>=0.21.0 <1.0.0` and `@appport/services` `>=0.15.0 <1.0.0`, and
ships npm's latest of both. FeltDB 0.20 refuses `collection.find()` past 1,000 matches; FeltKit reads
every multi-record result in `db.query` pages instead (docs/UPSTREAM-GAPS.md, "Review 2026-11-03"). AppPort Services takes `@feltdb/core` as a peer dependency, so it uses the
application's copy and npm installs exactly one, with no `overrides`. Two module copies in one process
would mean two runtimes and two sets of error classes, which is why Services must not bring its own
(releases before 0.11.0 pinned one exactly; with those, a project needed an override, and `feltkit
doctor` now says to update Services instead).

`feltkit doctor`, the first-run test, and the architecture test all fail if more than
one copy resolves, and `npm run test:release` fails on a second copy, on any override, or if the
installed Services release does not take `@feltdb/core` as a peer dependency.

## Request lifecycle of a mutation

1. Parse and validate arguments against the function's `args` schema.
2. Authorize: AppPort's authorizer evaluates the caller's roles against `access`.
3. Run the handler with a `Writer`. Reads see pending writes; writes are validated and buffered.
4. Validate the return value against `returns`, if declared.
5. Commit one FeltDB transaction: inserts as `requireAbsent`, updates/deletes with
   `ifVersion`, and unwritten point reads as preconditions. A failed precondition
   rejects the entire transaction (`CONFLICT`).
6. Nudge the change feed; record activity with the commit's transaction id, revision, and writes.

## Lifecycle

`FeltKitRuntime.start` opens the instance, builds every component, probes the
instance, checks services, and starts the change feed; if any step fails, the
instance is closed before the error propagates. `reload` swaps definitions (functions,
policy, AppPort application) without touching state. `close` stops the change feed,
waits for in-flight calls, flushes the activity log, and closes the instance.
`feltkit dev` and `feltkit start` handle SIGINT/SIGTERM with a 10-second deadline.
