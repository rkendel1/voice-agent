# Runtime components

**Status:** implemented in FeltKit (`feltkit({ components })`, `defineComponent`, build, dev, start, deploy,
health). The AppBoundry side (`components@1`) is specified below and implemented on AppBoundry's side
separately; see "On AppBoundry".

## Why

Some applications need code that is not a function but must run with the application: a telephony gateway
that receives provider webhooks (form-encoded, provider-signed, at public URLs) and holds a WebSocket per
call; a bridge to a message bus; a long-lived poller. Before this, such code could only run beside FeltKit in a
launcher the application wrote itself, and `feltkit build` / `feltkit deploy` did not carry it: a deployment
served the UI and silently lacked the component (the deployment reported healthy). A deployment that omits a
required part of the application is not a deployment.

## Decision

A component is **part of the application**, not a second service:

| Concern | Contract |
|---|---|
| Declaration | `feltkit({ components: { <name>: { entry, routes, websocket?, required?, principal, credentials?, network? } } })` in `feltkit/app.ts`, validated with the rest of the application (one configuration surface). |
| Code | `entry` (outside `feltkit/`) default-exports `defineComponent(async (ctx) => instance)` from `@feltdb/feltkit/server`. |
| Identity | The application's. A component acts only as `component:<name>` or as the principal of one of the application's own `app.agent`s; any other id (a person's, another component's) is refused at definition, build and start. That identity resolves from the declaration (no session to expire). It acts toward the application only by calling its functions (`ctx.call`): roles must be declared; `authorize`, validation and Activity apply. In a tenant it has exactly the membership a tenant manager granted it, resolved on every call, so a removed membership is refused on the next call. It has no database access of its own. |
| Durable work | A mutation records work for a component in its own transaction: `ctx.afterCommit.work(component, kind, input, { maxAttempts? })`. Nothing exists if the mutation rolls back. The component claims it with `ctx.work.claim({ kinds?, limit?, leaseMs? })` (only its own work; a lease fenced by a version) and settles it with `ctx.work.finish(item, outcome)`: `done` (with a receipt, kept on the record), `retry` (backoff; `failed` after `maxAttempts`, default 5), `failed`, or `unknown` (the effect may have happened: never retried automatically; a person retries it, recorded as theirs). An expired lease makes the item claimable again with `resumed: true`; the earlier performer's settle is refused (CONFLICT). Each item carries the tenant it was recorded in and its provenance (request, function, principal). Work survives restarts (it is a row in `_feltkit_outbox`). Not yet supported in an AppBoundry artifact (refused at the effect). |
| Secrets | Only the credential ids it declares (`ctx.credential(id)`), from FeltKit's custody (`FELTKIT_CREDENTIAL_<ID>` in production). Never in the artifact. `ctx.model()` gives the environment's selected model and key. `ctx.derive(purpose)` gives stable secret material (HMAC of the app's auth secret). |
| Routes | Declared HTTP path prefixes on the **application's port** (e.g. `/twilio/`), plus WebSocket upgrades on them when `websocket: true`. They may not overlap FeltKit's own paths or each other. Responses carry `X-FeltKit-Component: <name>`. In development they answer any Host (so a provider can reach them through a tunnel) while FeltKit's own routes stay loopback-only; the component authenticates its own traffic (provider signatures). |
| Process | Same process as the runtime (FeltDB local state is single-writer per volume). Started after the runtime, stopped before it (`SIGTERM` → `close()`), supervised with the application's process by whatever supervises it (container restart policy, Fly, systemd). No second process to launch after deployment. |
| Health | `instance.health()` → `{ state: ready \| starting \| unconfigured \| degraded \| failed, detail?, checks? }`. `/_feltkit/health` and `/_feltkit/deployment` include every component. Application `status`: **ready** (200) — runtime and every required component ready; **partial** (503) — runtime ready, a required component not (e.g. `unconfigured`); **unhealthy** (503) — runtime not ready, or a required component `failed`; **starting** (503). Named `checks` let a control plane say *which* part is unavailable (e.g. `webhooks` vs `media`). A component that throws at start is reported `failed` with the reason; the application keeps serving. |
| Build | `feltkit build` bundles each component to `.feltkit/build/components/<name>.mjs` (dependencies external, installed by the artifact), verifies it loads and default-exports a component, and records `{ name, entry, file, sha256, size, routes, websocket, required, principal, credentials, network }` in `.feltkit/build/manifest.json`. |
| Deploy | Every `feltkit deploy` target that runs FeltKit carries `.feltkit/build` whole, so the component, its digest and its declaration travel with the functions. The boot check fails (no artifact written) unless each component loaded (`ready` or `unconfigured` with isolated state and no production configuration) **and** its first route reaches it. DEPLOY.md lists components, routes, required credentials (`FELTKIT_CREDENTIAL_<ID>`) and the health semantics. The image's health check is `/_feltkit/health`, so a container whose required component is down is unhealthy. |
| Rollback | Unchanged per target: start the previous artifact/image on the same state. The component is inside the artifact, so it rolls back with the functions; `/_feltkit/deployment` reports the component digest that runs. |

Rejected:
- **A sidecar process or container per component** (on FeltKit's own targets): a second lifecycle, a second
  health surface and a second set of secrets for one application, and FeltDB local state cannot be shared
  between processes.
- **A second port**: Cloudflare and Vercel route one port; Caddy, Fly and Docker setups would each need a second
  route; path routing on the one port needs nothing new from any host.
- **An `inbound_webhook_events` surface only**: it would cover webhooks but not WebSocket media; components
  cover both and leave signature schemes to the application, where they are provider-specific.

## Example

```ts
// feltkit/app.ts
export const app = feltkit({
  name: "voice-agent",
  roles: { voice: ["voice.ingest", "voice.tools"] /* … */ },
  components: {
    voice: {
      entry: "gateway/component.ts",
      routes: ["/twilio/", "/simulator/"],
      websocket: true,
      required: true,
      principal: { id: "voice-runtime", roles: ["voice"] },
      credentials: ["twilio-auth-token"],
    },
  },
});

// gateway/component.ts
import { defineComponent } from "@feltdb/feltkit/server";
export default defineComponent(async (ctx) => {
  const voice = await startVoice(ctx); // uses ctx.call / ctx.credential / ctx.model / ctx.derive
  return { request: voice.request, upgrade: voice.upgrade, health: voice.health, close: voice.close };
});
```

## On AppBoundry (`components@1`)

An `appboundry.app/1` guest is a WebAssembly module with no network, no secrets, JSON-only routes and no
WebSocket upgrades — by design: the sandbox is AppBoundry's security boundary. A component therefore cannot run
*inside* the guest. The AppBoundry extension carries it **beside** the guest, in the same artifact and the same
deployment, under the same application identity:

- Manifest: runtime interface `components@1` and a top-level `components` array: `{ name, kind: "node", entry:
  "components/<name>.mjs", sha256, size, runtime: { node }, routes, websocket, required, principal, credentials,
  network }`. The component file is a self-contained bundle (node built-ins only), its digest bound to the
  artifact id (`sha256(manifest.json)`).
- The host runs one companion per component with the same context API (`ctx.call` → the guest's functions as
  the declared principal; declared credentials only, mounted from the host's secret store; `derive`), routes
  the declared prefixes (HTTP and WebSocket) to it, and reports per-component health in the deployment
  evidence. A deployment is Running/ready only when every required component is ready.
- Companion execution is native code outside the sandbox. It is **off by default** and must be enabled
  explicitly on a host; without it a deployment with components fails with a distinct code instead of running
  half an application.

`feltkit build --target appboundry` emits this section. Applications that use accounts, tenancy or
`app.agent` still cannot run on AppBoundry (FK-GAP-013; AppBoundry hosts have neither), whatever their
components.
